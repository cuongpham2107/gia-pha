 
<?php $__env->startSection('content1'); ?>
   
    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>
    <div id="tree">
        </div>
        
    <script>
        var chart = new OrgChart(document.getElementById("tree"), {
            enableDragDrop: true,
            nodeMenu: {
                add: { text: "Add" },
                remove: { text: "Remove" }
            },
            nodeBinding: {
                field_0: "id"
            }
        });
      
        chart.on('add', function (sender, node) {
            node.id = new Date().valueOf();
            node.pid = parseInt(node.pid);
            
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            $.ajax({
                type:'POST',
                url:"<?php echo e(route('nodes.store')); ?>",
                data: node,
                success:function(data){
                    sender.addNode(node); // node is adding
                }
            });
            return false;
        });
   
        chart.on('remove', function (sender, nodeId) {

                var url = "<?php echo e(URL('nodes')); ?>";
                var dltUrl = url+"/"+nodeId;

                $.ajax({
                    url: dltUrl,
                    type: "DELETE",
                    cache: false,
                    data:{
                        _token:'<?php echo e(csrf_token()); ?>'
                    },
                    success: function(dataResult){
                        var dataResult = JSON.parse(dataResult);
                        if(dataResult.statusCode==200){
                            $ele.fadeOut().remove();
                        }
                    }
                });

        });

        var app = <?php echo json_encode($nodes, 15, 512) ?>;
        chart.load(app);
    </script>
      
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/giapha/domains/giapha.kennatech.vn/public_html/resources/views/pages/nodes/index.blade.php ENDPATH**/ ?>