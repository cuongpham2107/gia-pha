
@extends('main')
@section('content')
<style>
   
    .backgrond-left{
        position: absolute;
        left: 1vw;
        top:45vh;
    }
    .backgrond-right{
        position: absolute;
        right: 1vw;
        top:45vh;
    }
    .backgrond-top{
       
        /* height: 250px; */
        width:100%;
        object-fit: cover;
        
    }
    .bft-search{
        right: 30px !important;
    }
    /* .bft-input>label {
        top: 8px !important;
    }
    .bft-form-field{
        min-width: 270px !important;
    }
    .bft-input>input, .bft-input>select{
        height: 40px !important;
        padding: 5px 10px 5px 9px !important;
    } */
    .bft-edit-form{
        z-index: 20;
    } 
    @media only screen and (max-width: 768px) {
            /* Ẩn các hình ảnh khi màn hình có chiều rộng nhỏ hơn hoặc bằng 768px */
            .backgrond-left,
            /* .backgrond-top, */
            .backgrond-right {
                display: none;
            }
            .backgrond-top{
                position: absolute;
                top:0;
                z-index: 20;
            }
        }
</style>
  
    <img class="backgrond-top"  src="https://giapha.kennatech.vn/assets/images/backgrount1.png" alt="">
    <div style="width:100%;" id="tree"></div>
    <img class="backgrond-left" src="https://giapha.kennatech.vn/assets/images/background2.png" alt="">
    <img class="backgrond-right" src="https://giapha.kennatech.vn/assets/images/background3.png" alt="">


    <script src="{{ asset('assets/js/orgchart.js') }}"></script>
    <script src="{{ asset('assets/js/familytree.js') }}"></script>
    <script src="{{ asset('assets/js/customFamilyTree.js') }}"></script>
    <script>
        
        let dataInit = {!!$branch->data!!};
        var family = new FamilyTree(document.getElementById("tree"), {
            align: OrgChart.align.center,
            enableSearch: false,
            mouseScrool: FamilyTree.action.zoom,
            nodeTreeMenu: true,
            // siblingSeparation: 160,
            // subtreeSeparation: 60,
            scaleInitial: FamilyTree.match.boundary,
            //miniMap: true,
            toolbar: {
                zoom: true,
                fit: true,
                fullScreen: true
            },
            editForm: {
                titleBinding: "name",
                photoBinding: "img",
                generateElementsFromFields: false,
                elements: [{
                        type: 'textbox',
                        label: 'Họ và tên',
                        binding: 'name'
                    },
                    {
                        type: 'textbox',
                        label: 'Hình ảnh',
                        binding: 'img',
                        btn: 'Upload'
                    },
                    {
                        type: 'date',
                        label: 'Ngày sinh',
                        binding: 'date_of_birth'
                    },
                    {
                        type: 'select',
                        label: 'Tình trạng',
                        binding: 'status',
                        options: [
                            {
                                value: 'cs',
                                text: 'Còn sống'
                            },
                            {
                                value: 'dm',
                                text: 'Đã mất'
                            }
                        ]
                    },
                    {
                        type: 'date',
                        label: 'Ngày mất',
                        binding: 'date_of_death'
                    },
                    {
                        type: 'textbox',
                        label: 'Nơi sinh',
                        binding: 'address_old'
                    },
                    {
                        type: 'textbox',
                        label: 'Thường trú',
                        binding: 'address'
                    },
                    {
                        type: 'textbox',
                        label: 'Trình độ học vấn',
                        binding: 'level'
                    },
                    {
                        type: 'textbox',
                        label: 'Công việc hiện tại',
                        binding: 'job'
                    },

                ],
                cancelBtn: 'Đóng',
                saveAndCloseBtn: 'Lưu và thoát',
                addMoreFieldName: 'Tên Trường',
                addMoreBtn: 'Thêm',
                addMore: 'Thêm trường dữ liệu',
                buttons: {
                    edit: {
                        icon: FamilyTree.icon.edit(24, 24, '#fff'),
                        text: 'Edit',
                        hideIfEditMode: true,
                        hideIfDetailsMode: false
                    },
                    share: null,
                    pdf: null,
                }
            },

            template: 'john',
            nodeBinding: {
                field_0: "name",
                field_1: "title",
                img_0: "img",
            }
        });
        family.load(dataInit);
        family.onUpdateNode( async (args) => {
            var data = await dataInit
            fetch('{{ route('branch.update',$branch->id) }}', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': '{{ csrf_token() }}'
                },
                body: JSON.stringify(data)
            })
            .then(response => {
                
            });
        });


        //upload Image
        family.editUI.on('element-btn-click', function(sender, args) {

            FamilyTree.fileUploadDialog(function(file) {
                var data = new FormData();
                data.append('files', file);
                fetch('{{ route('upload.photo') }}', {
                        method: 'POST',
                        headers: {
                            'X-CSRF-TOKEN': '{{ csrf_token() }}'
                        },
                        body: data
                    })
                    .then(response => {
                        response.json().then(responseData => {
                            // console.log(responseData);
                            args.input.value = responseData;
                            sender.setAvatar(responseData);
                        });
                    });
            });
        });
        family.draw();
    </script>
@endsection
