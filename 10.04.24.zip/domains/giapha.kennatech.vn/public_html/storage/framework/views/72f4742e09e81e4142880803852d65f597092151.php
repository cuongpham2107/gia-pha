<div >
    <div x-show="modalEditOpen" class="fixed inset-0 z-50 overflow-y-auto" aria-labelledby="modal-title" role="dialog" style="display: none"
        aria-modal="true">
        <div class="flex items-end justify-center min-h-screen px-4 text-center md:items-center sm:block sm:p-0">
            <div x-cloak @click="modalEditOpen = false" x-show="modalEditOpen"
                x-transition:enter="transition ease-out duration-300 transform" x-transition:enter-start="opacity-0"
                x-transition:enter-end="opacity-100" x-transition:leave="transition ease-in duration-200 transform"
                x-transition:leave-start="opacity-100" x-transition:leave-end="opacity-0"
                class="fixed inset-0 transition-opacity bg-gray-500 bg-opacity-40" aria-hidden="true"></div>

            <div x-cloak x-show="modalEditOpen" x-transition:enter="transition ease-out duration-300 transform"
                x-transition:enter-start="opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95"
                x-transition:enter-end="opacity-100 translate-y-0 sm:scale-100"
                x-transition:leave="transition ease-in duration-200 transform"
                x-transition:leave-start="opacity-100 translate-y-0 sm:scale-100"
                x-transition:leave-end="opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95"
                class="inline-block w-full max-w-xl p-8 my-10 overflow-hidden text-left transition-all transform bg-white rounded-lg shadow-xl 2xl:max-w-3xl">
                <div class="flex items-center justify-between space-x-4">
                    <div class="flex items-center space-x-2">
                        <h1 class="text-2xl font-semibold text-blue-800 ">Thông tin</h1>
                        <p class="m-0">(trường dữ liệu <span class="text-red-500">(*)</span> không được để trống)</p>
                    </div>

                    <button @click="modalEditOpen = false" class="text-gray-600 focus:outline-none hover:text-gray-700">
                        <svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" viewBox="0 0 24 24" style="fill: rgba(0, 0, 0, 1);transform: ;msFilter:;"><path d="m16.192 6.344-4.243 4.242-4.242-4.242-1.414 1.414L10.535 12l-4.242 4.242 1.414 1.414 4.242-4.242 4.243 4.242 1.414-1.414L13.364 12l4.242-4.242z"></path></svg>
                    </button>
                </div>

                

                <form class="mt-5" x-bind:action="`<?php echo e(route('member.update', '')); ?>/${id}`" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="grid grid-cols-2 gap-4">
                        <div>
                            <label for="user name"
                                class="block text-sm text-gray-700 capitalize dark:text-gray-200">Tên <span class="text-red-500">(*)</span></label>
                            <input placeholder="Họ và tên" type="text" 
                                x-model="name"
                                name="name"
                                class="block w-full px-3 py-2 mt-2 text-gray-600 placeholder-gray-400 bg-white border border-gray-200 rounded-md focus:border-indigo-400 focus:outline-none focus:ring focus:ring-indigo-300 focus:ring-opacity-40"
                                required
                                >
                        </div>

                        <div>
                            <label for="email"
                                class="block text-sm text-gray-700 capitalize dark:text-gray-200">Bố</label>
                            <input 
                                placeholder="" 
                                type="text"
                                readonly
                                x-model='parent'

                                class="block w-full px-3 py-2 mt-2 text-gray-600 placeholder-gray-400 bg-white border border-gray-200 rounded-md focus:border-indigo-400 focus:outline-none focus:ring focus:ring-indigo-300 focus:ring-opacity-40">
                            <input 
                                placeholder="" 
                                type="number"
                                readonly
                                x-model='parent_id'
                                class="block w-full px-3 py-2 mt-2 text-gray-600 placeholder-gray-400 bg-white border border-gray-200 rounded-md focus:border-indigo-400 focus:outline-none focus:ring focus:ring-indigo-300 focus:ring-opacity-40" style="display: none">
                        </div>
                    </div>
                    <div class="grid grid-cols-3 gap-4 mt-4">
                        <div>
                            <label for="user name" class="block text-sm text-gray-700 capitalize dark:text-gray-200">Năm
                                sinh<span class="text-red-500">(*)</span></label>
                            <input 
                                placeholder="Năm sinh" 
                                type="date"
                                x-model='date_of_birth'
                                name="date_of_birth"
                                class="block w-full px-3 py-2 mt-2 text-gray-600 placeholder-gray-400 bg-white border border-gray-200 rounded-md focus:border-indigo-400 focus:outline-none focus:ring focus:ring-indigo-300 focus:ring-opacity-40"
                                required>
                        </div>

                        <div>
                            <label for="email" class="block text-sm text-gray-700 capitalize dark:text-gray-200">Tình
                                trạng</label>
                            <select id="countries"
                            x-model='status'
                            name="status"
                                class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-3 mt-2 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500">
                                <option selected>--Chọn--</option>
                                <option value="live">Còn sống</option>
                                <option value="die">Đã mất</option>
                            </select>
                        </div>
                        <template x-if="status != 'live'">
                            <div>
                                <label for="user name" class="block text-sm text-gray-700 capitalize dark:text-gray-200">Năm
                                    Mất</label>
                                <input 
                                    placeholder="Năm mất" 
                                    type="date"
                                    x-model='date_of_death'
                                    name="date_of_death"
                                    class="block w-full px-3 py-2 mt-2 text-gray-600 placeholder-gray-400 bg-white border border-gray-200 rounded-md focus:border-indigo-400 focus:outline-none focus:ring focus:ring-indigo-300 focus:ring-opacity-40">
                            </div>
                            
                        </template>
                    </div>
                    <div class="mt-4">
                        <label for="user name" class="block text-sm text-gray-700 capitalize dark:text-gray-200">Nơi sinh<span class="text-red-500">(*)</span></label>
                        <input 
                            placeholder="Nơi sinh" 
                            type="text"
                            x-model='address_old'
                            name="address_old"
                            class="block w-full px-3 py-2 mt-2 text-gray-600 placeholder-gray-400 bg-white border border-gray-200 rounded-md focus:border-indigo-400 focus:outline-none focus:ring focus:ring-indigo-300 focus:ring-opacity-40"
                            required>
                    </div>
                    <div class="mt-4">
                        <label for="user name" class="block text-sm text-gray-700 capitalize dark:text-gray-200">Thường trú<span class="text-red-500">(*)</span></label>
                        <input 
                            placeholder="Thường trú" 
                            type="text"
                            x-model='address'
                            name="address"
                            class="block w-full px-3 py-2 mt-2 text-gray-600 placeholder-gray-400 bg-white border border-gray-200 rounded-md focus:border-indigo-400 focus:outline-none focus:ring focus:ring-indigo-300 focus:ring-opacity-40"
                            required>
                    </div>
                    <div class="grid grid-rows-3 grid-flow-col gap-4 mt-4">
                        <div>
                            <label for="user name"
                                class="block text-sm text-gray-700 capitalize dark:text-gray-200">Trình độ học vấn</label>
                            <input placeholder="Trình độ, học vấn" type="text"
                                x-model='level'
                                name="level"
                                class="block w-full px-3 py-2 mt-2 text-gray-600 placeholder-gray-400 bg-white border border-gray-200 rounded-md focus:border-indigo-400 focus:outline-none focus:ring focus:ring-indigo-300 focus:ring-opacity-40">
                        </div>

                        <div>
                            <label for="job"
                                class="block text-sm text-gray-700 capitalize dark:text-gray-200">Công việc</label>
                            <input 
                                placeholder="Công việc" 
                                type="text"
                                x-model='job'
                                name="job"
                                class="block w-full px-3 py-2 mt-2 text-gray-600 placeholder-gray-400 bg-white border border-gray-200 rounded-md focus:border-indigo-400 focus:outline-none focus:ring focus:ring-indigo-300 focus:ring-opacity-40">
                        </div>
                        <div class="row-span-3">
                            <label for="job"
                                class="block text-sm text-gray-700 capitalize dark:text-gray-200">Hình ảnh</label>
                            <img class="h-48" 
                                x-bind:src="image ? `<?php echo e(Voyager::image('${image}')); ?>` : '<?php echo e(asset('assets/images/photo.png')); ?>'"
                               
                                
                                src="<?php echo e(asset('assets/images/photo.png')); ?>" 
                                alt="">
                            <input 
                                type="file"
                                name="image"
                                class="block w-full px-3 py-1.5 mt-2 text-gray-600 placeholder-gray-400 bg-white border border-gray-200 rounded-md focus:border-indigo-400 focus:outline-none focus:ring focus:ring-indigo-300 focus:ring-opacity-40">
                        </div>
                    </div>
                    <div class="flex justify-between mt-6" >
                        <a href="#" @click.prevent="addNewParent()"
                        class="px-3 py-2 text-sm !text-white tracking-wide capitalize transition-colors duration-200 transform bg-green-500 rounded-md dark:bg-green-600 dark:hover:bg-green-700 dark:focus:bg-green-700 hover:bg-green-600 focus:outline-none focus:bg-green-500 focus:ring focus:ring-green-300 focus:ring-opacity-50">
                            Thêm con
                        </a>
                        <button type="submit" 
                            class="px-3 py-2 text-sm tracking-wide text-white capitalize transition-colors duration-200 transform bg-indigo-500 rounded-md dark:bg-indigo-600 dark:hover:bg-indigo-700 dark:focus:bg-indigo-700 hover:bg-indigo-600 focus:outline-none focus:bg-indigo-500 focus:ring focus:ring-indigo-300 focus:ring-opacity-50">
                            Sửa
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php /**PATH /home/giapha/domains/giapha.kennatech.vn/public_html/resources/views/components/modal-edit.blade.php ENDPATH**/ ?>