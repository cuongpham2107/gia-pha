<ul class="tree">
    <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li>
            <a href="#" @click="editMember(<?php echo e($item['id']); ?>)">
                <span>
                    <?php echo e($item['name']); ?>

                </span>
            </a>
            <?php if(!empty($item['children'])): ?>
                <?php echo $__env->make('components.member', ['items' => $item['children']], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>
        </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</ul>
<?php /**PATH /home/giapha/domains/giapha.kennatech.vn/public_html/resources/views/components/member.blade.php ENDPATH**/ ?>